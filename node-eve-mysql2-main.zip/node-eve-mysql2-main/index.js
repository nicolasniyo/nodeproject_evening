import express from "express";
import "dotenv/config";
import mysql from "mysql2/promise";
import bcrypt from "bcryptjs";

const app = express();
const db_con = await mysql.createConnection({
    user: process.env.DB_USER,
    port: process.env.DB_PORT,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    host: process.env.DB_HOST
});

app.use(express.json());

app.post("/register", async (req, res) => {
    try {
      const { username, email, password } = req.body;
  
      // making sure always the usename is in lowercase
      const newUsername = username.toLowerCase();

      const usernameExistQuery = "select * from user where username=?";
  
      const [rows] = await db_con.query(usernameExistQuery, [newUsername]);
      const checkUsernameExist= rows[0];
      
  
      if (checkUsernameExist) {
        return res.status(409).json({ message: "username already exist" });
      }
  
      const emailQuery = "select * from user where email=?";
      const [emailResult] = await db_con.query(emailQuery, [email]);
      const checkEmailExist = emailResult[0];
  
      if (checkEmailExist) {
        return res.status(409).json({ message: "Email already exist" });
      }
  
      const hashedPassword = await bcrypt.hash(password, 10);

      // inser into database
      const insertQuery = "insert into user (username, email, password) values (?, ?, ?)";
      const [resuts] = await db_con.query(insertQuery, [newUsername, email, hashedPassword]);
      const query = `select * from user where id='${resuts.insertId}'`;
      const [insertedUser] = await db_con.query(query);
  
      return res.status(201).json({
        message: "Registration is successful",
        userData: insertedUser[0],
      });
    } catch (error) {
      console.log(error);
      return res
        .status(500)
        .json({ message: "Server failure. Please try again after some time" });
    }
  });

  //Reetrieve all users
app.get("/users", async (req, res) => {
    try {
        const query = "select * from user";
        const [rows] = await db_con.query(query);
      return res.status(200).json(rows);
    } catch (error) {
      console.log(error);
      return res
        .status(500)
        .json({ message: "Server failure. Please try again after some time" });
    }
  });

  //change username/ update using params
app.patch("/users/:userId", async (request, response) => {
    try {
      const user_id = request.params.userId;
      const username = request.body.username;

      const newUsername = username.toLowerCase();
      const usernameQuery = "select username from user where username=?";
      const [usernameRes] = await db_con.query(usernameQuery, [newUsername]);
  
      const checkUsernameExist = usernameRes[0];
  
      if (checkUsernameExist) {
        return response.status(409).json({ message: "username already exist" });
      }
  
      const updateQuery = "update user set username=? where id=?";
      const [updateRes] = await db_con.query(updateQuery, [newUsername, user_id]);
      if (updateRes.affectedRows === 0) {
        return response.status(404).json({ message: "User not found" });
      };

      const query = "select * from user where id=?";
      const [res] = await db_con.query(query, [user_id]);
  
      return response.status(200).json(res[0]);
    } catch (error) {
      console.log(error);
      return response
        .status(500)
        .json({ message: "Server failure. Please try again after some time" });
    }
  });
  
  app.delete("/users/:userId", async (req, res) => {
    try {
      const user_id = req.params.userId;
     const deleteQuery = "delete from user where id=?";
     const [results] = await db_con.query(deleteQuery, [user_id]);
  
      if (results.affectedRows === 0) {
        return res.status(404).json({ message: "Record not found" });
      }
      return res.status(200).json({message: "Record deleted"});
    } catch (error) {
      console.log(error);
      return res
        .status(500)
        .json({ message: "Server failure. Please try again after some time" });
    }
  });

app.listen(process.env.PORT, ()=>console.log(`Server is running on port ${process.env.PORT}`))